package com.hackaton.questapp.rest;

import com.hackaton.questapp.dao.QuestStatusDao;
import com.hackaton.questapp.dao.TaskDao;
import com.hackaton.questapp.dao.TeamMemberDao;
import com.hackaton.questapp.entity.QuestStatusEntity;
import com.hackaton.questapp.entity.TaskEntity;
import com.hackaton.questapp.entity.TeamEntity;
import com.hackaton.questapp.entity.TeamMemberEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Sheremeta on 04.04.2015.
 */

@RestController
public class TaskService {

    private TeamMemberDao teamMemberDao;

    private QuestStatusDao questStatusDao;

    private TaskDao taskDao;

    @RequestMapping(value = "/getLatestTask", headers = "Accept=application/json")
    public TaskEntity getLatestAvialableTask(@RequestParam String deviceId){
        TeamMemberEntity teamMember = teamMemberDao.getTeamMemberById(deviceId);
        TeamEntity team = teamMember.getTeam();
        QuestStatusEntity status = questStatusDao.getByTeam(team);
        return taskDao.getTaskByNumberAndQuestId(status.getTasksCompleted()+1,team.getQuest().getQuestId());
    }

    @RequestMapping(value = "/attemptSolution", headers = "Accept=application/json")
    public String attemptSolution(@RequestParam String solutionCandidate,@RequestParam Long taskId,
                                  @RequestParam String deviceId){
        TaskEntity taskEntity = taskDao.getById(taskId);
        TeamMemberEntity teamMember = teamMemberDao.getTeamMemberById(deviceId);
        TeamEntity team = teamMember.getTeam();
        if(taskEntity.getSolution().equals(solutionCandidate)){ // trim
            QuestStatusEntity questStatusEntity = questStatusDao.getByTeam(team);
            if(questStatusEntity.getTasksCompleted() != taskEntity.getTaskOrdinalNumber() - 1) return "WRONG TASK ATTEMPTED";
            questStatusEntity.setTasksCompleted(questStatusEntity.getTasksCompleted() + 1);
            return "OK";
        } else {
            return "WRONG";
        }
    }

    public void setTeamMemberDao(TeamMemberDao teamMemberDao) {
        this.teamMemberDao = teamMemberDao;
    }

    public void setQuestStatusDao(QuestStatusDao questStatusDao) {
        this.questStatusDao = questStatusDao;
    }

    public void setTaskDao(TaskDao taskDao) {
        this.taskDao = taskDao;
    }
}
