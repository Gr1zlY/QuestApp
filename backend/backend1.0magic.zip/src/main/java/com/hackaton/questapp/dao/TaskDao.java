package com.hackaton.questapp.dao;

import com.hackaton.questapp.entity.TaskEntity;

/**
 * Created by Sheremeta on 04.04.2015.
 */
public class TaskDao extends AbstractDao<TaskEntity>{
    public TaskEntity getTaskByNumberAndQuestId(long taskNumber,Long questId){
        for (TaskEntity taskEntity : getAll()) {
            if(taskEntity.getTaskOrdinalNumber() == taskNumber && taskEntity.getQuest().getQuestId().equals(questId))
                return taskEntity;
        }
        return null;
    }


}
